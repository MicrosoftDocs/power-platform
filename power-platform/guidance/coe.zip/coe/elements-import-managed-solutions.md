---
title: "Import Managed Solutions | MicrosoftDocs"
description: ""
author: manuelap-msft
manager: devkeydet
ms.service: power-platform
ms.component: pa-admin
ms.topic: conceptual
ms.date: 04/10/2020
ms.subservice: guidance
ms.author: mapichle
ms.reviewer: jimholtz
search.audienceType: 
  - admin
search.app: 
  - D365CE
  - PowerApps
  - Powerplatform
---
# Import Managed Solutions

[!INCLUDE[footer-include](../../includes/footer-banner.md)]