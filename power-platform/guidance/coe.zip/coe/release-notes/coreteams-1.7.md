---
title: "Release notes and latest version of the CoE starter kit Core components for Teams 1.7 | MicrosoftDocs"
description: "Release notes and latest version of the CoE Starter Kit for Teams 1.8."
author: manuelap-msft
manager: devkeydet
ms.service: power-platform
ms.component: pa-admin
ms.topic: conceptual
ms.date: 05/08/2021
ms.subservice: guidance
ms.author: mapichle
ms.reviewer: jimholtz
search.audienceType: 
  - admin
search.app: 
  - D365CE
  - PowerApps
  - Powerplatform
---

# Released version Core Components for Teams 1.8

Version 1.7 for the CoE Starter Kit Core Components for Tams is now available. This article describes the updates, including the new features and the fixes to existing functionality, included in this release. This version was first made available on May 8, 2021.

## Bug Fixes

Bug fixes to the Admin | Welcome Email and the Sync Flows have been implemented.

[!INCLUDE[footer-include](../../../includes/footer-banner.md)]