---
title: "Release notes and latest version of the CoE starter kit Theming Components | MicrosoftDocs"
description: "Release notes and latest version of the CoE Starter Kit."
author: manuelap-msft
manager: devkeydet
ms.service: power-platform
ms.component: pa-admin
ms.topic: conceptual
ms.date: 04/10/2020
ms.subservice: guidance
ms.author: mapichle
ms.reviewer: jimholtz
search.audienceType: 
  - admin
search.app: 
  - D365CE
  - PowerApps
  - Powerplatform
---

# Released version Theming Components 1.1

Version 1.1 for the CoE Starter Kit Theming Components is now available. This article describes the updates, including the new features and the fixes to existing functionality, included in this release. This version was first made available on July 20, 20202

This is the first version of the Theming Components.

[!INCLUDE[footer-include](../../../includes/footer-banner.md)]