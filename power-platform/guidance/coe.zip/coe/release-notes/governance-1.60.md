---
title: "Release notes and latest version of the CoE starter kit Governance components 1.60 | MicrosoftDocs"
description: "Release notes and latest version of the CoE starter kit Governance components 1.60."
author: manuelap-msft
manager: devkeydet
ms.service: power-platform
ms.component: pa-admin
ms.topic: conceptual
ms.date: 05/05/2021
ms.subservice: guidance
ms.author: mapichle
ms.reviewer: jimholtz
search.audienceType: 
  - admin
search.app: 
  - D365CE
  - PowerApps
  - Powerplatform
---

# Released version Governance Components 1.60

Version 1.60 for the CoE Starter Kit Governance Components is now available. This article describes the updates, including the new features and the fixes to existing functionality, included in this release. This version was first made available on May 5, 2021.

## Moving components to Core

Admin | Compliance detail request has been moved from Governance components to Core components to accommodate changes to make this flow compatible with Dataverse for Teams environments.

[!INCLUDE[footer-include](../../../includes/footer-banner.md)]