---
title: "Release notes and latest version of the CoE starter kit Nurture Components 1.23 | MicrosoftDocs"
description: "Release notes and latest version of the CoE Starter Kit 1.23."
author: manuelap-msft
manager: devkeydet
ms.service: power-platform
ms.component: pa-admin
ms.topic: conceptual
ms.date: 10/16/2020
ms.subservice: guidance
ms.author: mapichle
ms.reviewer: jimholtz
search.audienceType: 
  - admin
search.app: 
  - D365CE
  - PowerApps
  - Powerplatform
---

# Released version Nurture Components 1.23

Version 1.23 for the CoE Starter Kit Nurture Components is now available. This article describes the updates, including the new features and the fixes to existing functionality, included in this release. This version was first made available in preview on October 16, 2020.

## Bug fixes

A dependency issue was introduced with the latest release, and fixed with this one.

[!INCLUDE[footer-include](../../../includes/footer-banner.md)]