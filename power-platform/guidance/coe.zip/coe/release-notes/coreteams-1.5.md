---
title: "Release notes and latest version of the CoE starter kit Core components for Teams 1.6 | MicrosoftDocs"
description: "Release notes and latest version of the CoE Starter Kit for Teams 1.5."
author: manuelap-msft
manager: devkeydet
ms.service: power-platform
ms.component: pa-admin
ms.topic: conceptual
ms.date: 04/08/2021
ms.subservice: guidance
ms.author: mapichle
ms.reviewer: jimholtz
search.audienceType: 
  - admin
search.app: 
  - D365CE
  - PowerApps
  - Powerplatform
---

# Released version Core Components for Teams 1.6

Version 1.6 for the CoE Starter Kit Core Components for Tams is now available. This article describes the updates, including the new features and the fixes to existing functionality, included in this release. This version was first made available on April 8, 2021.

This is the first version of the Core Components for Teams:
[Set up Core Components in Teams](../setup-core-components.md)

[!INCLUDE[footer-include](../../../includes/footer-banner.md)]